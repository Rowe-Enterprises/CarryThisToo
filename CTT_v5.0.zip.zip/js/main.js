jQuery(document).ready(function($) {

    // $(window).scroll(function(event) {
    //     if ($(window).scrollTop() > 800 ){
    //         $("nav").css("visibility", "visible");
    //         $("nav").css("opacity", "1");
    //     } else {
    //         $("nav").css("visibility", "hidden");
    //         $("nav").css("opacity", "0");
    //         $("nav").css("transition", "visibility .3s, opacity 0.3s ease-in;");
    //     }
    // });

    $(".feature-chips").hover(function($){
        $("")
    })
});

autosize(document.querySelectorAll('textarea'));

document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.scrollspy');
    var options = {
        scrollOffset: 100
    };
    var instances = M.ScrollSpy.init(elems, options);
});

var len_text = document.getElementById("len_text");

function maxLength(el) {	
	if (!('maxLength' in el)) {
		var max = el.attributes.maxLength.value;
		
	}
}
document.getElementById('text-area').onkeyup = function () {
    var max = 1000;
    if (this.value.length >= max) return false;
    console.log((max - this.value.length));
    len_text.innerHTML = (max - this.value.length) +"/" + max;
};

var premium = document.querySelector('#premium');
premium.addEventListener('click', function(){
    window.location = "#pricing";
})
var main = document.querySelector('.main');
var relativeOffset = anime.timeline({
    // direction: 'alternate',
    // loop: true,
    // complete: function(anim) {
    //     main.style.display = "block";
    // }
});

relativeOffset
.add({
    targets: '#relativeOffset .square-1.el',
    scaleX: {
        value: 0,
        easing: 'easeInOutQuart'
    },
})
.add({
    targets: '#relativeOffset .square-2.el',
    scaleX: {
        value: 0,
        easing: 'easeInOutQuart'
    },
    offset: '-=600' // Starts 600ms before the previous animation ends
})
.add({
    targets: '#relativeOffset .square-3.el',
    scaleX: {
        value: 0,
        easing: 'easeInOutQuart'
    },
    offset: '-=800' // Starts 600ms before the previous animation ends
});

// relativeOffset.complete = function() {   

// };


// relativeOffset
// .add({
//     targets: '#relativeOffset .square-1.el',
//     scaleY: {
//         value: 0,
//         easing: 'easeInOutQuart'
//     },
// })
// .add({
//     targets: '#relativeOffset .square-2.el',
//     scaleY: {
//         value: 0,
//         easing: 'easeInOutQuart'
//     },
//     offset: '-=600' // Starts 600ms before the previous animation ends
// })
// .add({
//     targets: '#relativeOffset .square-3.el',
//     scaleY: {
//         value: 0,
//         easing: 'easeInOutQuart'
//     },
//     offset: '-=800' // Starts 600ms before the previous animation ends
// });
