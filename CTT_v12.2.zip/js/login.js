var el = document.querySelector('.tabs');
var instance = M.Tabs.init(el, {});