function upvote(el) {
    // console.log(el.id);
    var id = el.id;
    document.getElementById(id).style.color = "#bf0a30";
}

function downvote(el){
    var id = el.id;
    document.getElementById(id).style.color = "#bf0a30";
}